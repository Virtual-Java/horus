Bienvenido a la documentación de Horus
======================================

.. image:: images/horus-logo.png
   :alt: The Horus Logo
   :align: right


Contenido:

.. toctree::
   :maxdepth: 2

   guia-rapida/index.rst
   bancos-de-trabajo/index.rst
