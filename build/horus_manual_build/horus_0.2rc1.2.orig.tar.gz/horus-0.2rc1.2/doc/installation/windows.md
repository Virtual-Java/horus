# Horus installation in Windows ![][windows-logo]

[return to Home](../../README.md)

### Version 0.2 release candidate 1

First install USB Camera drivers:

* [Logitech Camera C270 Drivers](http://support.logitech.com/en_us/product/hd-webcam-c270)

Download Horus installer:

* [Horus 0.2rc1 installer](https://github.com/bqlabs/horus/releases/download/0.2rc1/Horus_0.2rc1.exe)

Execute the installer and follow the wizard. This package contains all dependencies and also Arduino and FTDI drivers.

Reboot the computer to apply the changes.

[windows-logo]: ../images/windows.png
