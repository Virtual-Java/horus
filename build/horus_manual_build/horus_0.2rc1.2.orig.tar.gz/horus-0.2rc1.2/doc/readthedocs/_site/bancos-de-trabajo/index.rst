.. _sec-bancos-de-trabajo:

Bancos de trabajo
=================

.. toctree::
   :maxdepth: 2

   menu.rst
   control.rst
   ajuste.rst
   calibracion.rst
   escaneado.rst
