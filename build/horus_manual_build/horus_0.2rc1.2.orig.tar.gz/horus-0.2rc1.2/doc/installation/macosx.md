# Horus installation in Mac OS X ![][macosx-logo]

[return to Home](../../README.md)

### Version 0.2 release candidate 1

First update your FTDI drivers:

* [FTDI USB Drivers](http://www.ftdichip.com/Drivers/VCP/MacOSX/FTDIUSBSerialDriver_v2_3.dmg)

Download Horus installer:

* [Horus 0.2rc1 installer](https://github.com/bqlabs/horus/releases/download/0.2rc1/Horus_0.2rc1.dmg)

Execute the installer and drag Horus icon into *Applications*.

Reboot the computer to apply the changes.

[macosx-logo]: ../images/macosx.png
